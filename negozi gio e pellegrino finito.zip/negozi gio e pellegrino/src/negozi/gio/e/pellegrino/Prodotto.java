public class Prodotto
{
private int costo;
private String nome; 
private int quantità;

public prodotto(int costo,String nome,int quantità){
setCosto(costo);
setNome(nome);
setQuantatià(quantità);
}
public void setCosto(int costo){
this.costo=costo;
}

public void setNome(String nome){
this.nome=nome;
}

public void setQuantatià(int quantatià){
this.quantatià=quantatià;
}

public int getCosto(){
return costo;
}

public String getNome(){
return nome;
}

public int getQuantatià(){
return quantatià;
}

}