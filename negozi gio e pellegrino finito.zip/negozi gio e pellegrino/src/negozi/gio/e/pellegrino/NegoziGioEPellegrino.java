/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package negozi.gio.e.pellegrino;

/**
 *
 * @author Studente
 */
public class NegoziGioEPellegrino {
    public static void main(String[] args) {
        Prodotto listaprodotti[]=new Prodotto[10];
        Prodotto l=new Prodotto("pantaloni",100,10);
        Prodotto l1=new Prodotto("felpe",100,10);
        Prodotto l2=new Prodotto("maglie",100,10);
        Prodotto l3=new Prodotto("giacca",100,10);
        Prodotto l4=new Prodotto("cappelli",100,10);
        Prodotto l5=new Prodotto("scarpe",100,10);
        Prodotto l6=new Prodotto("calzini",100,10);
        Prodotto l7=new Prodotto("pantaloncini",100,10);
        Prodotto l8=new Prodotto("cinture",100,10);
        Prodotto l9=new Prodotto("giubbino di cennamo",100,10);
        
        
        listaprodotti[0]=l;
        listaprodotti[1]=l1;
        listaprodotti[2]=l2;
        listaprodotti[3]=l3;
        listaprodotti[4]=l4;
        listaprodotti[5]=l5;
        listaprodotti[6]=l6;
        listaprodotti[7]=l7;
        listaprodotti[8]=l8;
        listaprodotti[9]=l9;
        
        
        Negozio p=new Negozio("Pellegrino's clothing","Via Carcere Parmenide 32",listaprodotti);
        
        
        
    }
    
}
