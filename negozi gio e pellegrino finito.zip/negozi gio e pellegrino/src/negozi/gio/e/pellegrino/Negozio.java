public class Negozio{
    private int nome;
    private int indirizzo;
    private int Magazzino;
    private String Cassa;
    
      public Cliente(String nome,String indirizzo){
        setNome(nome);
        setIndirizzo(indirizzo);
    }
    public int getNome(){
        return nome;
    }
    public int getIndirizzo(){
    return indirizzo;
    }
    public int getMagazzino(){
        return prodotto;
    }
    public String getCassa(){
        return cassa;
    }
    
public void setNome(String nome){
    this.nome=nome;
}
public void setIndirizzo(String indirizzo){
    this.indirizzo=indirizzo;
}
public void setMagazzino(int magazzino){
    this.magazzino=magazzino;
}
public void setCassa(int cassa){
    this.cassa=cassa;
}
}