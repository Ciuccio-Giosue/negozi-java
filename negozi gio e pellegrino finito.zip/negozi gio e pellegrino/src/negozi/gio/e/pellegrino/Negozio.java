public class Negozio{
    private String nome;
    private String indirizzo;
    private Prodotto[] Magazzino;
    private float Cassa;
    
      public Negozio(String nome,String indirizzo){
        setNome(nome);
        setIndirizzo(indirizzo);
    }
    public String getNome(){
        return nome;
    }
    public String getIndirizzo(){
    return indirizzo;
    }
    public Prodotto getMagazzino(){
        return Magazzino;
    }
    public float getCassa(){
        return Cassa;
    }
    
public void setNome(String nome){
    this.nome=nome;
}
public void setIndirizzo(String indirizzo){
    this.indirizzo=indirizzo;
}
public void setMagazzino(Prodotto magazzino){
    this.magazzino=magazzino;
}
public void setCassa(float cassa){
    this.cassa=cassa;
}
public float getCassa(){
    return cassa;
}
}